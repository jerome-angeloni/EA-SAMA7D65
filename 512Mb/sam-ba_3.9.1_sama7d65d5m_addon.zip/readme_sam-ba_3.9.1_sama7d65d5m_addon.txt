Please unzip the provided archive (sam-ba_3.9.1_sama7d65d5m_addon.zip) into the SAM-BA v3.9.1 install folder.
The "SAMA7D65.qml" file in "qml\SAMBA\Device\SAMA7D65" folder must be overwritten by the provided one.

Then it is easy to program the device

    ./sam-ba -p serial -b sama7d65d5m -a <applet_name>